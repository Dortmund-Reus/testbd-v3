TL_MQTT mqtt;
// 配置mqtt连接参数
int port = 1883;
char servername[] = "a1SOtraBSgw.iot-as-mqtt.cn-shanghai.aliyuncs.com";
char clientname[] = "FESA234FBDS24|securemode=3,signmethod=hmacsha1,timestamp=789|";
char topicName[] = "/sys/a1SOtraBSgw/TempDev/thing/event/property/post";
char username[] = "TempDev&a1SOtraBSgw";
char password[] = "37046bc661f84b75bca3a5820c67468a01320399";

void setup() {
    cout << "temperature setup" << endl;
    TL_WiFi.init();
    TL_WiFi.join("AZFT","AZFT123456");
    mqtt = TL_WiFi.fetchMQTT();
    mqtt.connect(servername, port, clientname, username, password);
}

void loop() {
    cout << "start reading" << endl;
    TL_Temperature.read();
    String data = String(" {\"params\": {\"CurrentTemperature\":") + TL_Temperature.data() + String("},\"method\":\"thing.event.property.post\"}");
    cout << data << endl;
    
    char buf[100];
    data.toCharArray(buf, 100);
    // TL_Serial.print("Temp data is ");
    // TL_Serial.println(TL_Temperature.data());
    int res = mqtt.publish(topicName, buf, strlen(buf));
    cout << "Temp publish res is "<< res << endl;
    TL_Time.delayMinutes(1);
    cout << "end reading" << endl;
}
