#include "test1.hpp"
 
void test1print()
{
	printf("this is a test!\n");
}
