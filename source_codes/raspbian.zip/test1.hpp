#include <stdio.h>
 
void test1print(void);
