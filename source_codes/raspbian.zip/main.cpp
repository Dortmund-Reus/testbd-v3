#include "test1.hpp"
int main()
{
	test1print()
	return 0;
}
