

/* user space */
#ifndef RHINO_CONFIG_USER_SPACE
#define RHINO_CONFIG_USER_SPACE              0
#endif

